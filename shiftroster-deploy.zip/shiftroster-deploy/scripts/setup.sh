#!/bin/bash
# ══════════════════════════════════════════════════════════
#  ShiftRoster — Automated Server Setup Script
#  Tested on: Ubuntu 20.04 / 22.04 / Debian 11+
#  Usage: chmod +x scripts/setup.sh && sudo ./scripts/setup.sh
# ══════════════════════════════════════════════════════════

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; NC='\033[0m'; BOLD='\033[1m'

log()  { echo -e "${GREEN}✔ $1${NC}"; }
info() { echo -e "${BLUE}ℹ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠ $1${NC}"; }
err()  { echo -e "${RED}✘ $1${NC}" >&2; exit 1; }

echo -e "\n${BOLD}══════════════════════════════════════${NC}"
echo -e "${BOLD}   ShiftRoster 2026 — Server Setup    ${NC}"
echo -e "${BOLD}══════════════════════════════════════${NC}\n"

# ── Check root
[[ $EUID -ne 0 ]] && err "Please run as root: sudo ./scripts/setup.sh"

# ── Variables (edit these)
APP_DIR="/var/www/shiftroster"
APP_USER="www-data"
DOMAIN=""          # e.g. "roster.yourcompany.com" — leave empty to skip SSL
PORT=3000
USE_NGINX=true
USE_PM2=true

# ── 1. Update system
info "Updating system packages..."
apt-get update -qq && apt-get upgrade -y -qq
log "System updated"

# ── 2. Install Node.js 20
if ! command -v node &>/dev/null; then
  info "Installing Node.js 20..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - -qq
  apt-get install -y nodejs -qq
  log "Node.js $(node -v) installed"
else
  log "Node.js $(node -v) already installed"
fi

# ── 3. Install PM2
if $USE_PM2; then
  if ! command -v pm2 &>/dev/null; then
    info "Installing PM2..."
    npm install -g pm2 -q
    log "PM2 installed"
  else
    log "PM2 already installed"
  fi
fi

# ── 4. Install Nginx
if $USE_NGINX; then
  if ! command -v nginx &>/dev/null; then
    info "Installing Nginx..."
    apt-get install -y nginx -qq
    systemctl enable nginx
    systemctl start nginx
    log "Nginx installed and started"
  else
    log "Nginx already installed"
  fi
fi

# ── 5. Create app directory
info "Setting up application directory: $APP_DIR"
mkdir -p "$APP_DIR/logs" "$APP_DIR/public"
log "Directories created"

# ── 6. Copy app files
info "Copying application files..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cp "$SCRIPT_DIR/server.js"          "$APP_DIR/"
cp "$SCRIPT_DIR/package.json"       "$APP_DIR/"
cp "$SCRIPT_DIR/ecosystem.config.js" "$APP_DIR/"
cp "$SCRIPT_DIR/public/index.html"  "$APP_DIR/public/"
log "Application files copied to $APP_DIR"

# ── 7. Install dependencies
info "Installing Node.js dependencies..."
cd "$APP_DIR"
npm install --production -q
log "Dependencies installed"

# ── 8. Set permissions
chown -R "$APP_USER:$APP_USER" "$APP_DIR"
chmod -R 755 "$APP_DIR"
chmod -R 777 "$APP_DIR/logs"
log "Permissions set"

# ── 9. Setup Nginx
if $USE_NGINX; then
  info "Configuring Nginx..."
  cat > /etc/nginx/sites-available/shiftroster << NGINX
server {
    listen 80;
    listen [::]:80;
    server_name ${DOMAIN:-_};

    gzip on;
    gzip_types text/html text/css application/javascript;

    location / {
        proxy_pass         http://127.0.0.1:${PORT};
        proxy_http_version 1.1;
        proxy_set_header   Upgrade \$http_upgrade;
        proxy_set_header   Connection 'upgrade';
        proxy_set_header   Host \$host;
        proxy_set_header   X-Real-IP \$remote_addr;
        proxy_set_header   X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_cache_bypass \$http_upgrade;
    }

    location /health {
        proxy_pass http://127.0.0.1:${PORT}/health;
    }
}
NGINX

  ln -sf /etc/nginx/sites-available/shiftroster /etc/nginx/sites-enabled/
  rm -f /etc/nginx/sites-enabled/default
  nginx -t && systemctl reload nginx
  log "Nginx configured"

  # SSL with Certbot
  if [[ -n "$DOMAIN" ]]; then
    info "Setting up SSL for $DOMAIN..."
    if ! command -v certbot &>/dev/null; then
      apt-get install -y certbot python3-certbot-nginx -qq
    fi
    certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "admin@$DOMAIN" --redirect
    log "SSL configured for $DOMAIN"
  fi
fi

# ── 10. Start with PM2
if $USE_PM2; then
  info "Starting application with PM2..."
  cd "$APP_DIR"
  pm2 start ecosystem.config.js --env production
  pm2 save
  pm2 startup systemd -u root --hp /root | tail -1 | bash
  log "Application started with PM2"
  pm2 status
else
  # Systemd fallback
  info "Setting up systemd service..."
  cp "$SCRIPT_DIR/scripts/shiftroster.service" /etc/systemd/system/
  sed -i "s|/var/www/shiftroster|$APP_DIR|g" /etc/systemd/system/shiftroster.service
  systemctl daemon-reload
  systemctl enable shiftroster
  systemctl start shiftroster
  log "Systemd service started"
fi

# ── 11. Open firewall
if command -v ufw &>/dev/null; then
  ufw allow 80/tcp  2>/dev/null || true
  ufw allow 443/tcp 2>/dev/null || true
  log "Firewall rules added"
fi

# ── Done
echo ""
echo -e "${BOLD}${GREEN}══════════════════════════════════════${NC}"
echo -e "${BOLD}${GREEN}   ✅ ShiftRoster deployed!           ${NC}"
echo -e "${BOLD}${GREEN}══════════════════════════════════════${NC}"
echo ""
SERVER_IP=$(hostname -I | awk '{print $1}')
echo -e "  🌐 URL:      http://${DOMAIN:-$SERVER_IP}"
echo -e "  📡 Port:     $PORT (internal)"
echo -e "  📁 App dir:  $APP_DIR"
echo -e "  📋 Logs:     pm2 logs shiftroster"
echo -e "  🔄 Restart:  pm2 restart shiftroster"
echo -e "  🛑 Stop:     pm2 stop shiftroster"
echo ""

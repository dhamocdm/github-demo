// PM2 Ecosystem Config — ShiftRoster 2026
// Usage: pm2 start ecosystem.config.js

module.exports = {
  apps: [
    {
      name:         'shiftroster',
      script:       'server.js',
      instances:    'max',          // Use all CPU cores
      exec_mode:    'cluster',      // Cluster mode for load balancing
      watch:        false,
      max_memory_restart: '250M',

      env: {
        NODE_ENV: 'development',
        PORT:     3000,
        HOST:     '0.0.0.0',
      },
      env_production: {
        NODE_ENV: 'production',
        PORT:     3000,
        HOST:     '0.0.0.0',
      },

      // Logging
      log_date_format:  'YYYY-MM-DD HH:mm:ss',
      out_file:         './logs/out.log',
      error_file:       './logs/error.log',
      merge_logs:       true,
      log_type:         'json',

      // Auto-restart on failure
      autorestart:      true,
      restart_delay:    3000,
      max_restarts:     10,

      // Graceful shutdown
      kill_timeout:     5000,
      wait_ready:       true,
      listen_timeout:   8000,
    }
  ]
};
